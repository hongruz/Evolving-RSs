1. This is the code used in the experiments on the evolving RS model.
2. We use the code in the folder 'Simulation' to run simulations of our model and testify the results for degree and vertex weight distributions in user and item groups.
3. We use the code in the folder 'RealDatasetValidation' to validate our model on several real RS datasets.
4. Prior to run the .py files in the folder 'ReadDatasetValidation', please download corresponding datasets from the given urls and save them in the correct directory shown in .py files. 
5. We provide here a sample dataset file for the BookCrossing RS and the code in the folder 'ReadDatasetValidation/BookCrossing' is ready for testing.