This is the code used in the experiments on the evolving RS model.
We use the code in the folder 'Simulation' to run simulations of our model and testify the results for degree and vertex weight distributions in user and item groups.
We use the code in the folder 'RealDatasetValidation' to validate our model on several real RS datasets.

Prior to run the .py files in the folder 'ReadDatasetValidation', please download corresponding datasets from the given urls.